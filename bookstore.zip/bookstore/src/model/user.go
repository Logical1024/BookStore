package model

//User 用户
type User struct {
	ID       int    //用户编号
	Username string //用户名
	Password string //密码
	Email    string //邮箱
}
